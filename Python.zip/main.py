class library:    
  def _init_(self):
      self.nobooks=0
      self.book=[]
  def add_books(self,book):
      self.book.append(book)
      self.nobooks=len(self.book)
  def display_books(self):
      print(f"the number of books present in te library are{self.book}.the books are ")
    for book in self.book:
        print(book)
l1=library()
l1.add_books("think and grow rich")
l1.display_books()


# first i have created the class of library.
# then i have created the cunstructor to store the books.
# in that i have created the instance variables as to add books and to count the no of books 
# present in the library.
# next i have added books anf displayed th ebooks using functions.